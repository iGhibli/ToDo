//
//  SquareModel.swift
//  ToDo
//
//  Created by iGhibli on 2020/11/30.
//

struct SquareModel {
    var icon: String = ""
    var item: String = ""
    var content: String = ""
}
