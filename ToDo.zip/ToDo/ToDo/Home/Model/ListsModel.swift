//
//  List.swift
//  ToDo
//
//  Created by iGhibli on 2020/11/29.
//

struct ListsModel {
    var icon: String = ""
    var title: String = ""
    var count: Int = 0
}
