//
//  StyleBaseView.swift
//  ToDo
//
//  Created by iGhibli on 2020/11/29.
//

import UIKit

class SquareView: UIView {
    
    private lazy var icon: UIImageView = {
        let icon = UIImageView()
        return icon
    }()
    
    private lazy var item: UILabel = {
        let item = UILabel()
        item.textAlignment = .right
        return item
    }()
    private lazy var content: UILabel = {
        let content = UILabel()
        return content
    }()
    
    var squareModel = SquareModel() {
        didSet {
//            icon.image = UIImage(systemName: squareModel.icon)
//            item.text = squareModel.item
//            content.text = squareModel.content
        }
    }
    
    
//    override class func awakeFromNib() {
//        super.awakeFromNib()
//        
//    }
    
    // MARK: Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override open func layoutSubviews() {
        super.layoutSubviews()
        
        backgroundColor = .white
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 8
        
//        // MARK: Subviews Setup
//        addSubview(icon)
//        addSubview(item)
//        addSubview(content)
//        
//        icon.snp.makeConstraints { (make) in
//            make.top.left.equalTo(self).offset(10)
//            make.width.height.equalTo(20)
//        }
//        
//        item.snp.makeConstraints { (make) in
//            make.top.bottom.equalTo(icon)
//            make.right.equalTo(self).offset(-10)
//        }
//        
//        content.snp.makeConstraints { (make) in
//            make.top.equalTo(icon.snp.bottom).offset(10)
//            make.left.right.equalTo(self).offset(10)
//            make.bottom.equalTo(self).offset(10)
//        }
    }
}
