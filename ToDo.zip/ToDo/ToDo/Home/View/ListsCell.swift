//
//  ListsCell.swift
//  ToDo
//
//  Created by iGhibli on 2020/11/30.
//

import UIKit

class ListsCell: UITableViewCell {

    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var item: UILabel!
    @IBOutlet weak var count: UILabel!
    @IBOutlet weak var iconBg: UIView!
    @IBOutlet weak var testView: TestView!
    
    // 线宽
    let lineWidth = 1 / UIScreen.main.scale
    
    var listsModel = ListsModel() {
        didSet {
            icon.image = UIImage(systemName: listsModel.icon)
            item.text = listsModel.title
            count.text = "\(listsModel.count)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        selectionStyle = .none
        backgroundColor = .clear
        iconBg.layer.masksToBounds = true
        iconBg.layer.cornerRadius = iconBg.bounds.size.width / 2
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        // 自绘分割线
        guard let context = UIGraphicsGetCurrentContext() else { return }
        context.setFillColor(UIColor.white.cgColor)
        context.fill(rect)
        
        context.setLineCap(.square)
        context.setLineWidth(lineWidth)
        context.setStrokeColor(UIColor(red: 188/255, green: 187/255, blue: 193/255, alpha: 1.0).cgColor)
        context.beginPath()
        context.move(to: CGPoint(x: 47, y: rect.size.height - lineWidth))
        context.addLine(to: CGPoint(x: rect.size.width, y: rect.size.height - lineWidth))
        context.strokePath()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    static var nib: UINib {
        UINib(nibName: String(describing: self), bundle: nil)
    }
    
    static let reuseIdentifier: String = String(describing: self)
}
