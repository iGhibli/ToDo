//
//  HeaderView.swift
//  ToDo
//
//  Created by iGhibli on 2020/12/1.
//

import UIKit

class HeaderView: UITableViewHeaderFooterView {
    
    @IBOutlet weak var dictumView: SquareView!
    @IBOutlet weak var todayView: SquareView!
    @IBOutlet weak var scheduledView: SquareView!
    @IBOutlet weak var allView: SquareView!
    @IBOutlet weak var flaggedView: SquareView!
    
    var dictumSquareModel = SquareModel() {
        didSet {
            dictumView.squareModel = dictumSquareModel
        }
    }
    
    var todaySquareModel = SquareModel() {
        didSet {
            todayView.squareModel = todaySquareModel
        }
    }
    
    var scheduledSquareModel = SquareModel() {
        didSet {
            scheduledView.squareModel = scheduledSquareModel
        }
    }
    
    var allSquareModel = SquareModel() {
        didSet {
            allView.squareModel = allSquareModel
        }
    }
    
    var flaggedSquareModel = SquareModel() {
        didSet {
            flaggedView.squareModel = flaggedSquareModel
        }
    }
    
    static var nib: UINib {
        UINib(nibName: String(describing: self), bundle: nil)
    }
    
    static let reuseIdentifier: String = String(describing: self)
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
