//
//  TestHeaderView.swift
//  ToDo
//
//  Created by iGhibli on 2020/12/1.
//

import UIKit

class TestHeaderView: UITableViewHeaderFooterView {
    

    @IBOutlet weak var testView: TestView!
    
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }

    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    static var nib: UINib {
        UINib(nibName: String(describing: self), bundle: nil)
    }
    
    static let reuseIdentifier: String = String(describing: self)

}
