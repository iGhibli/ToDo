//
//  TestView.swift
//  ToDo
//
//  Created by iGhibli on 2020/12/1.
//

import UIKit

class TestView: UIView {

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        print("---------init coder-----------")
        backgroundColor = .red
    }
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
